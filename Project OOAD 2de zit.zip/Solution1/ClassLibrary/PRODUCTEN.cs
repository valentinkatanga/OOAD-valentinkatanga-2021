﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace ClassLibrary
{
    public class PRODUCTEN
    {
        //connectiestring
        private static string connString = ConfigurationManager.AppSettings["connString"];
        public int  Id { get; set; }
        public string naam { get; set; }
        public string beschrijving { get; set; }
        public string foto { get; set; }
        
        public int prijs { get; set; }
        public PRODUCTEN()
        {
        }

        public PRODUCTEN(int id) : this()
        {
            Id = id;
        }
        public PRODUCTEN(int id, string nm, string besc, string ft, int px) : this(id)
        {


            naam = nm;
            beschrijving = besc;
            foto = ft;
            prijs = px;
        }

        // ToString
        public override string ToString()
        {
            return $"{Id}: {naam} {beschrijving}";
        }



        // methods
        public static List<PRODUCTEN> GetAll()
        {
            List<PRODUCTEN> product = new List<PRODUCTEN>();
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand("SELECT id, naam, foto, prijs, beschrijving FROM PRODUCT", conn);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["id"]);
                    string naam = Convert.ToString(reader["naam"]);
                    string beschrijving = Convert.ToString(reader["beschrijving"]);
                    string foto = Convert.ToString(reader["foto"]);
                    int prijs = Convert.ToInt32(reader["prijs"]);
                    product.Add(new PRODUCTEN(id, naam, beschrijving, foto, prijs));
                }
            }
            return product;
        }
        public static PRODUCTEN FindById(int productId)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand("SELECT naam, beschrijving, foto, prijs FROM PRODUCT WHERE ID = @parID", conn);
                comm.Parameters.AddWithValue("@parID", productId);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                if (!reader.Read()) return null;
                string naam = Convert.ToString(reader["naam"]);
                string beschrijving = Convert.ToString(reader["beschrijving"]);
                string foto = Convert.ToString(reader["foto"]);
                int prijs = Convert.ToInt32(reader["prijs"]);
                return new PRODUCTEN(productId, naam, beschrijving, foto, prijs);
            }
        }
        public void DeleteFromDb()
        {
            // verwijder product
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("ALTER TABLE WINKELMANDITEM nocheck constraint all ALTER TABLE PRODUCTCATEGORIE nocheck constraint all DELETE FROM PRODUCT WHERE id = @parID ALTER TABLE WINKELMANDITEM check constraint all ALTER TABLE PRODUCTCATEGORIE check constraint all", conn);
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }
        }
        public int InsertToDb()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand(
                    "insert into PRODUCT(naam, beschrijving, foto, prijs) output INSERTED.ID values (@param1, @param2, @param3, @param4)", conn);
                comm.Parameters.AddWithValue("@param1", naam);
                comm.Parameters.AddWithValue("@param2", beschrijving);
                comm.Parameters.AddWithValue("@param3", foto);
                comm.Parameters.AddWithValue("@param4", prijs);
                return (int)comm.ExecuteScalar();


            }
        }

        
        public void UpdateInDb()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();


                SqlCommand comm = new SqlCommand(
                    @"UPDATE PRODUCT
                        set naam=@nm, beschrijving=@bes, foto=@ft, prijs=@px
                        where ID = @parID"
                    , conn);
                comm.Parameters.AddWithValue("@nm", naam);
                comm.Parameters.AddWithValue("@bes", beschrijving);
                comm.Parameters.AddWithValue("@ft", foto);
                comm.Parameters.AddWithValue("@px", prijs);
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }
        }

        }
    }

