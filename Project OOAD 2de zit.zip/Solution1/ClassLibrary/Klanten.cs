﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Klanten
    {
        //connectiestring
        private static string connString = ConfigurationManager.AppSettings["connString"];
        public int Id { get; set; }
        public string voornaam { get; set; }
        public string achternaam { get; set; }
        public DateTime? geboortedatum { get; set; }
        public string straat { get; set; }
        public string nummer { get; set; }
        public string postcode { get; set; }
        public string gemeente { get; set; }
        public string gsm { get; set; }

        public Klanten()
        {
        }

        public Klanten(int id, string vn, string an) : this()
        {
            Id = id;
            voornaam = vn;
            achternaam = an;
        }
        public Klanten(int id, string vn, string an,DateTime? gb, string str, string nr, string pc, string gmt, string _gsm) : this(id, vn, an)
        {
            geboortedatum = gb;
            straat = str;
            nummer = nr;
            postcode = pc;
            gemeente = gmt;
            gsm = _gsm;
        }

        // ToString
        public override string ToString()
        {
            return $"{Id}: {voornaam} {achternaam}";
        }



        // methods
        public static List<Klanten> GetAll()
        {
            List<Klanten> klant = new List<Klanten>();
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand("SELECT id, voornaam, achternaam, geboortedatum, straat, nummer, postcode, gemeente, gsm FROM KLANT", conn);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["id"]);
                    string voornaam = Convert.ToString(reader["voornaam"]);
                    string achternaam = Convert.ToString(reader["achternaam"]);
                    DateTime? geboortedatum = reader["geboortedatum"] == DBNull.Value ? null : (DateTime?)Convert.ToDateTime(reader["geboortedatum"]);
                    string straat = Convert.ToString(reader["straat"]);
                    string nummer = Convert.ToString(reader["nummer"]);
                    string postcode = Convert.ToString(reader["postcode"]);
                    string gemeente = Convert.ToString(reader["gemeente"]);
                    string gsm = Convert.ToString(reader["gsm"]);
                    klant.Add(new Klanten(id, voornaam, achternaam, geboortedatum, straat, nummer, postcode, gemeente, gsm));
                }
            }
            return klant;
        }
        public static Klanten FindById(int klantId)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand("SELECT voornaam, achternaam, geboortedatum, straat, nummer, postcode, gemeente, gsm FROM KLANT WHERE ID = @parID", conn);
                comm.Parameters.AddWithValue("@parID", klantId);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                if (!reader.Read()) return null;
                string voornaam = Convert.ToString(reader["voornaam"]);
                string achternaam = Convert.ToString(reader["achternaam"]);
                DateTime? geboortedatum = reader["geboortedatum"] == DBNull.Value ? null : (DateTime?)Convert.ToDateTime(reader["geboortedatum"]);
                string straat = Convert.ToString(reader["straat"]);
                string nummer = Convert.ToString(reader["nummer"]);
                string postcode = Convert.ToString(reader["postcode"]);
                string gemeente = Convert.ToString(reader["gemeente"]);
                string gsm = Convert.ToString(reader["gsm"]);
                return new Klanten(klantId, voornaam, achternaam, geboortedatum, straat, nummer, postcode, gemeente, gsm);
            }
        }
        public int InsertToDb()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand(
                    "insert into KLANT(voornaam, achternaam, geboortedatum, straat, nummer, postcode, gemeente, gsm) output INSERTED.ID values (@param1, @param2, @param3, @param4, @param5, @param6, @param7, @param8)", conn);
                comm.Parameters.AddWithValue("@param1", voornaam);
                comm.Parameters.AddWithValue("@param2", achternaam);
                comm.Parameters.AddWithValue("@param3", geboortedatum);
                comm.Parameters.AddWithValue("@param4", straat);
                comm.Parameters.AddWithValue("@param5", nummer);
                comm.Parameters.AddWithValue("@param6", postcode);
                comm.Parameters.AddWithValue("@param7", gemeente);
                comm.Parameters.AddWithValue("@param8", gsm);
                return (int)comm.ExecuteScalar();


            }
        }

        public void UpdateInDb()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();


                SqlCommand comm = new SqlCommand(
                    @"UPDATE KLANT
                        set voornaam=@vn, achternaam=@an, geboortedatum=@gb, straat=@str, nummer=@nr, postcode=@pc, gemeente=@gmt, gsm = @gsm
                        where ID = @parID"
                    , conn);
                comm.Parameters.AddWithValue("@vn", voornaam);
                comm.Parameters.AddWithValue("@an", achternaam);
                comm.Parameters.AddWithValue("@gb", geboortedatum);
                comm.Parameters.AddWithValue("@str", straat);
                comm.Parameters.AddWithValue("@nr", nummer);
                comm.Parameters.AddWithValue("@pc", postcode);
                comm.Parameters.AddWithValue("@gmt", gemeente);
                comm.Parameters.AddWithValue("@gsm", gsm);
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }

        }


        public void DeleteFromDb()
        {
            // verwijder klant
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("ALTER TABLE WINKELMAND nocheck constraint all DELETE FROM Klant WHERE id = @parID ALTER TABLE WINKELMAND check constraint all", conn);
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }
        }
    }


}
