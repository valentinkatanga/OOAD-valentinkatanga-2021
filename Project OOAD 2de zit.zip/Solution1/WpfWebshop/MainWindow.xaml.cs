﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary;
using System.Linq;

namespace WpfWebshop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Winkelmandje winkelmandje = new Winkelmandje();
        string connString = ConfigurationManager.AppSettings["connString"];
        public MainWindow()
        {
            InitializeComponent();
            ReloadProducten(null);
        }
        private void LsBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)lsBox.SelectedItem;

            int prodId = Convert.ToInt32(item.Tag);
            PRODUCTEN prod = PRODUCTEN.FindById(prodId);
            lblnaam.Content = prod.naam;
            lblprijs.Content = "€" + prod.prijs + ",00";
            txtBlckbes.Text = prod.beschrijving;


        }
        public void ReloadProducten(int? selectedId)
        {
            lsBox.Items.Clear();
            lblnaam.Content = "";
            lblnaam.Content = "";
            txtBlckbes.Text = "";

            List<PRODUCTEN> alleproducten = PRODUCTEN.GetAll();
            foreach (PRODUCTEN product in alleproducten)
            {
                ListBoxItem item = new ListBoxItem();
                item.Content = product.ToString();
                item.Tag = product.Id;
                item.IsSelected = selectedId == product.Id;
                lsBox.Items.Add(item);
                

            }
        }


        private void btnWinkelmandje_Click(object sender, RoutedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)lsBox.SelectedItem;
            int prodId = Convert.ToInt32(item.Tag);
            winkelmandje.Show();
        }

        private void btnToevoeg_Click(object sender, RoutedEventArgs e)
        {
            ListBoxItem  item = (ListBoxItem)lsBox.SelectedItem;
            int prodId = Convert.ToInt32(item.Tag) + 1;
            winkelmandje._prodId = prodId;
            winkelmandje.ItemToevoegen();
        }

  

        private void btnSort_Click(object sender, RoutedEventArgs e)
        {
List<PRODUCTEN> prods = new List<PRODUCTEN>();
            foreach (ListBoxItem item in lsBox.Items)
            {
                PRODUCTEN prod = PRODUCTEN.FindById(Convert.ToInt32(item.Tag));
                prods.Add(prod);
            }
            List<PRODUCTEN> sorted = prods.OrderByDescending(p => p.prijs).ToList();

          

            lsBox.Items.Clear();
            lblnaam.Content = "";
            lblnaam.Content = "";
            txtBlckbes.Text = "";

            foreach (PRODUCTEN product in sorted)
            {
                ListBoxItem item = new ListBoxItem();
                item.Content = product.ToString();
                item.Tag = product.Id;
                item.IsSelected = false;
                lsBox.Items.Add(item);


            }
        }
    }
}
