﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary;

namespace WpfWebshop
{
    
    /// <summary>
    /// Interaction logic for Winkelmandje.xaml
    /// </summary>
    public partial class Winkelmandje : Window {  

        public int _prodId;
        
        public Winkelmandje()
        {
            InitializeComponent();
          

        }
        public void ItemToevoegen()
        {
            PRODUCTEN prod1 = PRODUCTEN.FindById(_prodId);
            ListBoxItem item = new ListBoxItem();
            Console.WriteLine(_prodId);
            item.Content = prod1.ToString();
            item.Tag = prod1.Id;
            lsBox.Items.Add(prod1);
        }

        private void btnReserveren_Click(object sender, RoutedEventArgs e)
        {
            lsBox.Items.Clear();
            txtBan.Text = "";
            txtBgmt.Text = "";
            txtBvn.Text = "";
            txtBstr.Text = "";
            txtBpc.Text = "";
        }
    }
}
