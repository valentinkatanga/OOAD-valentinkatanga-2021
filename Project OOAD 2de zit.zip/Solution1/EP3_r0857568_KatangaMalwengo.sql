If not exists(select * from sys.databases where name = 'EP3_r0857568_KatangaMalwengo')
begin
create database [EP3_r0857568_KatangaMalwengo]
end


go
    use EP3_r0857568_KatangaMalwengo





go
drop table if exists PRODUCTCATEGORIE
drop table if exists WINKELMANDITEM
drop table if exists WINKELMAND
drop table if exists MEDEWERKER
drop table if exists KLANT
drop table if exists CATEGORIE
drop table if exists PRODUCT
drop table if exists OUDEklanten
drop table if exists PRODUCThistory

drop view if exists vwProduct
drop view if exists vwKlant
drop view if exists vwWinkelmand
drop view if exists vwWinkelmandItem 
drop view if exists vwCategorie 
drop view if exists vwProductCategorie
drop view if exists vwWinkelmandperKlant
drop view if exists vwProductperCategorie
drop view if exists vwPrijstijdensSolden
drop view if exists vwDeluxeProducten

drop procedure if exists spProductToevoegen
drop procedure if exists spProductWijzigen 
drop procedure if exists spProductVerwijderen
drop procedure if exists spKlantToevoegen
drop procedure if exists spKlantWijzigen 
drop procedure if exists spKlantVerwijderen
drop procedure if exists spWinkelmandToevoegen
drop procedure if exists spWinkelmandWijzigen 
drop procedure if exists spWinkelmandVerwijderen
drop procedure if exists spWinkelmandItemToevoegen
drop procedure if exists spWinkelmandItemWijzigen 
drop procedure if exists spWinkelmandItemVerwijderen
drop procedure if exists spCategorieToevoegen
drop procedure if exists spCategorieWijzigen 
drop procedure if exists spCategorieVerwijderen
drop procedure if exists spProductCategorieToevoegen
drop procedure if exists spProductCategorieWijzigen 
drop procedure if exists spProductCategorieVerwijderen

drop function if exists fnPrijsWinkelmand
drop function if exists fnAantalVerkocht
drop function if exists fn_Solden
drop function if exists fnProductOpzoekenperPrijs

drop trigger if exists triOUDEklanten
drop trigger if exists triProductAanpassen


----------------------------------------------------TABLES
go
create table  PRODUCT
(
	id int identity(1,1) not null,
	naam nvarchar(100) not null,
	beschrijving nvarchar(max) not null,
	foto nvarchar(max) null,
	prijs int not null,
	constraint PK_Product primary key (id)
); 


create table MEDEWERKER 
(
	id int identity(1,1) not null,
	voornaam nvarchar(100) not null,
	achternaam nvarchar(100) not null,
	code_pasje nchar(13) not null,
	passwoord nvarchar(100) not null,
	constraint PK_MEDEWERKER primary key (id),
	constraint UK_MEDEWERKER_code_pasje unique (code_pasje)
);

create table  KLANT
(
	id int identity(1,1) not null,
	voornaam nvarchar(100) not null,
	achternaam nvarchar(100) not null,
	geboortedatum date not null,
	straat nvarchar(255) not null,
	nummer nvarchar(5) not null,
	postcode int not null,
	gemeente nvarchar(255) not null,
	gsm nvarchar(20) null,
	constraint PK_Klant primary key (id)
); 

create table WINKELMAND
(
	id int identity(1,1) not null,
	datum_aanmaak nvarchar(100) default getdate() not null,
	_status nvarchar(100) not null,
	klant_id int,
	constraint FK_WINKELMAND_klant foreign key (klant_id) references KLANT (id),
	constraint PK_Winkelmand primary key (id),
	constraint CK_WINKELMAND_status check (_status like 'betaald' or _status like 'niet betaald'),
	
);

create table WINKELMANDITEM
(
	id int identity(1,1) not null,
	winkelmand_id int not null,
	product_id int not null,
	aantal int not null
	constraint FK_WINKELMANDITEM_product foreign key (product_id) references PRODUCT (id),
	constraint FK_WINKELMANDITEM_winkelmand foreign key (winkelmand_id) references WINKELMAND (id)
);
create table CATEGORIE
(
	id int identity(1,1) not null,
	naam nvarchar(25) not null,
	constraint PK_Categorie primary key (naam)
);

create table PRODUCTCATEGORIE
(
	id int identity(1,1) not null,
	categorie_naam nvarchar(25) not null,
	product_id int not null,
	constraint	PK_PRODUCTCATEGORIE_categorie_product_id primary key (categorie_naam, product_id),
	constraint FK_PRODUCTCATEGORIE_categorie_naam foreign key (categorie_naam) references CATEGORIE (naam),
	constraint FK_PRODUCTCATEGORIE_product_id foreign key (product_id) references PRODUCT (id)
);


create table OUDEklanten
(
	table_naam nvarchar(20),
	manipulatie nvarchar(20),
	datum_n_Tijd datetime2 default getdate()
);
create table PRODUCThistory(
	table_naam nvarchar(20),
	manipulatie nvarchar(20),
	datum_n_Tijd datetime2 default getdate(),
);
----------------------------------------------------VIEWS
go
create view vwProduct
as select id, naam, beschrijving, foto, prijs 
from PRODUCT

go
create view vwKlant
as select naam, beschrijving, foto, prijs 
from PRODUCT

go
create view vwWinkelmand
as select id, datum_aanmaak, _status
from WINKELMAND

go
create view vwWinkelmandItem
as select winkelmand_id, product_id, aantal
from WINKELMANDITEM

go
create view vwCategorie
as select naam
from CATEGORIE

go
create view vwProductCategorie
as select categorie_naam, product_id
from PRODUCTCATEGORIE

go 
create view vwWinkelmandperKlant
as select W.id, W._status, W.datum_aanmaak, W.klant_id, K.voornaam, K.achternaam
from WINKELMAND W inner join KLANT K
on  W.klant_id = K.id

go 
create view vwProductperCategorie
as select PC.categorie_naam, P.naam
from PRODUCTCATEGORIE PC inner join PRODUCT P
on PC.product_id = P.id



------------------------------------------------------PROCEDURES
go


-- return 0 = product successvol toegevoegd
create procedure spProductToevoegen
	@naam nvarchar(100),
	@beschrijving nvarchar(max),
	@foto nvarchar(max),
	@prijs int
as
begin
	insert into PRODUCT (naam, beschrijving, foto, prijs) values (@naam, @beschrijving, @foto,@prijs )
	return 0
end

go
-- return 0 = product successvol gewijzigd
create procedure spProductWijzigen
	@id int,
	@naam nvarchar(100),
	@beschrijving nvarchar(max),
	@foto nvarchar(max),
	@prijs int
as
begin
--nooit meer
	ALTER TABLE WINKELMANDITEM nocheck constraint all	
	ALTER TABLE PRODUCTCATEGORIE nocheck constraint all	
	update PRODUCT set naam = @naam, beschrijving = @beschrijving ,foto =  @foto, prijs = @prijs  where id = @id
	ALTER TABLE WINKELMANDITEM nocheck constraint all	
	ALTER TABLE PRODUCTCATEGORIE nocheck constraint all	
	return 0
end

go
-- return resultaat 1 = id bestaat niet'!!!!!!!!!!!!'
-- return resultaat 0 = succesvol
create procedure spProductVerwijderen 
	@id int
as
begin 
	declare @resultaat int = 0
	ALTER TABLE WINKELMANDITEM nocheck constraint all ALTER TABLE PRODUCTCATEGORIE nocheck constraint all	

	if exists (select * from PRODUCT where id = @id)
	begin
		delete PRODUCT where id = @id

		ALTER TABLE WINKELMANDITEM check constraint all ALTER TABLE PRODUCTCATEGORIE check constraint all
	end
	else 
	begin 
		set @resultaat = 1
		end
	return @resultaat

end

-----------------------------

go


-- return 0 = klant successvol toegevoegd
create procedure spKlantToevoegen
	@voornaam nvarchar(100),
	@achternaam nvarchar(100),
	@geboortedatum date,
	@straat nvarchar(255),
	@nummer nvarchar(5),
	@postcode int,
	@gemeente nvarchar(255),
	@gsm nvarchar(20) 
as
begin
	insert into KLANT(voornaam, achternaam, geboortedatum, straat, nummer, postcode, gemeente, gsm) values (@voornaam, @achternaam, @geboortedatum,@straat, @nummer, @postcode,@gemeente, @gsm)
	return 0
end

go


-- return 0 = wijziging heeft plaats gevonden
create procedure spKlantWijzigen
	@id int,
	@voornaam nvarchar(100),
	@achternaam nvarchar(100),
	@geboortedatum date,
	@straat nvarchar(255),
	@nummer nvarchar(5),
	@postcode int,
	@gemeente nvarchar(255),
	@gsm nvarchar(20) 
as
begin
	update KLANT set voornaam = @voornaam, achternaam = @achternaam, geboortedatum = @geboortedatum, straat = @straat, nummer = @nummer, postcode = @postcode, gemeente = @gemeente, gsm = @gsm where id = @id
	return 0
end

go
-- return resultaat 1 = id bestaat niet 
-- return resultaat 0 = succesvol
create procedure spKlantVerwijderen 
	@id int
as
begin
	declare @resultaat int = 0
	if exists (select * from KLANT where id = @id)
	begin
	ALTER TABLE WINKELMAND nocheck constraint all	
		delete KLANT where id = @id
		ALTER TABLE WINKELMAND check constraint all
	end
	else 
	begin	
		set @resultaat = 1
	end
	return @resultaat

end

-----------------------------

go
-- return 0 = winkelmand successvol toegevoegd
create procedure spWinkelmandToevoegen
	@datum_aanmaak nvarchar(100), 
	@_status nvarchar(100) 
as
begin
	insert into WINKELMAND(datum_aanmaak, _status) values (@datum_aanmaak, @_status)
	return 0
end

go
-- return 0 = wijziging heeft plaats gevonden
create procedure spWinkelmandWijzigen
	@id int,
	@datum_aanmaak nvarchar(100), 
	@_status nvarchar(100) 
as
begin
	update WINKELMAND set datum_aanmaak = @datum_aanmaak, _status =  @_status where id = @id
	return 0
end

go
-- return resultaat 1 = id bestaat niet
-- return resultaat 0 = succesvol
create procedure spWinkelmandVerwijderen
	@id int
as
begin 
declare @resultaat int = 0
	
		if exists (select * from WINKELMAND where id = @id)
		begin
			delete WINKELMAND where id = @id
		end
		else 
	begin
		set @resultaat = 1
	end
	return @resultaat

end

-----------------------------

go
-- return 0 : winkelmanditem succesvol toegevoegd
create procedure spWinkelmandItemToevoegen
	@aantal int, 
	@winkelmand_id int,
	@product_id int


as
begin
	insert into WINKELMANDITEM(aantal, winkelmand_id, WINKELMANDITEM.product_id) values (@aantal, @winkelmand_id,@product_id)
	return 0
end

go
-- return 0 wijziging succesvol
create procedure spWinkelmandItemWijzigen
	@id int,
	@aantal int, 
	@winkelmand_id int,
	@product_id int 
as
begin
	update WINKELMANDITEM set aantal = @aantal, winkelmand_id =  @winkelmand_id, @product_id = product_id  where id = @id
	return 0
end

go
-- return resultaat 1 = id bestaat niet
-- return resultaat 0 = succesvol
create procedure spWinkelmandItemVerwijderen
	@id int
as
begin
	declare @resultaat int = 0
	if exists (select * from WINKELMANDITEM where id = @id)
	begin
		delete WINKELMANDITEM where id = @id
	end
	else
	begin
		set @resultaat = 1
	end
	return @resultaat

end

-----------------------------

go
-- return 0 = categorie succesvol toegevoegd
create procedure spCategorieToevoegen
	@naam nvarchar(25) 
as
begin
	insert into CATEGORIE(naam) values (@naam)
	return 0
end

go
-- return 0 = wijziging succesvol
create procedure spCategorieWijzigen
	@id int,
	@naam nvarchar(25) 
as
begin
	update CATEGORIE set naam = @naam where id = @id
	return 0
end

go
-- return resultaat 1 = id bestaat niet
-- return resultaat 0 = succesvol
create procedure spCategorieVerwijderen
	@id int
as
begin
	declare @resultaat int = 0
	if exists (select * from CATEGORIE where id = @id)
	begin
		delete CATEGORIE where id = @id
	end
	else
	begin
		set @resultaat = 1
	end
	return @resultaat

end

-----------------------------

go
-- return 0 = productcategorie succesvol toegevoegd
create procedure spProductCategorieToevoegen
	@categorie_naam nvarchar(25), 
	@product_id int
as
begin
	insert into PRODUCTCATEGORIE(PRODUCTCATEGORIE.categorie_naam, product_id) values (@categorie_naam, @product_id)
	return 0
end

go
-- return 0 = wijziging succesvol
create procedure spProductCategorieWijzigen
	@categorie_naam nvarchar(25), 
	@product_id int, 
	@id int
as
begin
	update PRODUCTCATEGORIE set categorie_naam = @categorie_naam, product_id = @product_id  where id = @id
	return 0
end

go
-- return resultaat 1 = id bestaat niet
-- return resultaat 0 = succesvol
create procedure spProductCategorieVerwijderen
	@id int
as
begin
	declare @resultaat int = 0
	if exists (select * from PRODUCTCATEGORIE where id = @id)
	begin
		delete PRODUCTCATEGORIE where id = @id
	end
	else
	begin
		set @resultaat = 1
	end
	return @resultaat

end
----------------------------------------------------FUNCTIES

go

create or alter function fnPrijsWinkelmand (@id int)
returns int
as
begin
	--declare variables
	declare @totalprice int;

	--get value of item
	select @totalprice = sum(PRODUCT.prijs)
	from WINKELMANDITEM 
		inner join PRODUCT on PRODUCT.id = WINKELMANDITEM.product_id
	where  WINKELMANDITEM.winkelmand_id = @id
	return @totalprice
end




go

create or alter function fnAantalVerkocht (@id int)
returns int
as
begin
--join product overbodig
	declare @aantal int;
	select @aantal = sum(WINKELMANDITEM.aantal)
	from  WINKELMANDITEM
		inner join PRODUCT on PRODUCT.id = WINKELMANDITEM.product_id
		inner join WINKELMAND on WINKELMAND.id = WINKELMANDITEM.winkelmand_id
	where  WINKELMAND._status = 'betaald' and PRODUCT.id = @id
	return @aantal
end


-----------------nieuwe functies


--parameters datum

go 
create or alter function fn_Solden (@id int)
returns int 
as 
begin
declare @prijs int
select @prijs = product.prijs
from PRODUCT 
where @id = product.id
if getdate() between '07-31-2021' and '08-30-2021'
set 
	@prijs = @prijs * 0.75
	return @prijs
end

go
create or alter function fnProductOpzoekenperPrijs ( @prijs int )
returns table
as
return
select id as 'Id Product', naam as 'Deluxe Producten'
from PRODUCT
where PRODUCT.prijs >= @prijs;


----------------------------------------------------TRIGGERS


--go
--create trigger triOUDEklanten on KLANT after delete
--as
--begin
--	insert into OUDEklanten(table_naam, manipulatie, datum_n_Tijd) values ('KLANT', 'delete', GETDATE())

--end

--go
--create trigger triProductToevoegen on PRODUCT after insert
--as
--begin

--	insert into PRODUCThistory ( table_naam, manipulatie, datum_n_Tijd) values ('PRODUCT', 'insert', GETDATE())
--end


----------------------------------------------------ROLLEN

--go
--create login r0857568_Admin with password = ''; 
--create login r0857568_Klant with password = '';
--create user Admin1 for login r0857568_Admin; 
--create user Klant for login r0857568_Klant;
--go


--grant select, insert, update, delete on schema::PRODUCTCATEGORIE to Admin1;
--grant select, insert, update, delete on schema::PRODUCT  to Admin1;
--grant select, insert, update, delete on schema::MEDEWERKER to Admin1;
--grant select, insert, update, delete on schema::WINKELMAND to Admin1;
--grant select, insert, update, delete on schema::WINKELMANDITEM  to Admin1;
--grant select, insert, update, delete on schema::KLANT to Admin1;
--grant select, insert, update, delete on schema::CATEGORIE to Admin1;
--grant select, insert, update, delete on schema::OUDEklanten  to Admin1;
--grant select, insert, update, delete on schema::PRODUCThistory to Admin1;

--grant select, insert, update, delete on schema::spProductToevoegen to Admin1;
--grant select, insert, update, delete on schema::spProductWijzigen  to Admin1;
--grant select, insert, update, delete on schema::spProductVerwijderen to Admin1;
--grant select, insert, update, delete on schema::spKlantToevoegen to Admin1;
--grant select, insert, update, delete on schema::spKlantWijzigen  to Admin1;
--grant select, insert, update, delete on schema::spKlantVerwijderen to Admin1;
--grant select, insert, update, delete on schema::spWinkelmandToevoegen to Admin1;
--grant select, insert, update, delete on schema::spWinkelmandWijzigen  to Admin1;
--grant select, insert, update, delete on schema::spWinkelmandVerwijderen to Admin1;
--grant select, insert, update, delete on schema::spWinkelmandItemToevoegen to Admin1;
--grant select, insert, update, delete on schema::spWinkelmandItemWijzigen  to Admin1;
--grant select, insert, update, delete on schema::spWinkelmandItemVerwijderen to Admin1;
--grant select, insert, update, delete on schema::spCategorieToevoegen to Admin1;
--grant select, insert, update, delete on schema::spCategorieWijzigen  to Admin1;
--grant select, insert, update, delete on schema::spCategorieVerwijderen to Admin1;

--grant select, insert, update, delete on schema::fnPrijsWinkelmand to Admin1;
--grant select, insert, update, delete on schema::fn_Solden to Admin1;
--grant select, insert, update, delete on schema::fnAantalVerkocht to Admin1;
--grant select, insert, update, delete on schema::fn_Winkelmanden_per_dag to Admin1;

--grant select, insert, update, delete on schema::vwProduct to Admin1;
--grant select, insert, update, delete on schema::vwKlant to Admin1;
--grant select, insert, update, delete on schema::vwWinkelmand to Admin1;
--grant select, insert, update, delete on schema::vwWinkelmandItem  to Admin1;
--grant select, insert, update, delete on schema::vwCategorie  to Admin1;
--grant select, insert, update, delete on schema::vwProductCategorie to Admin1;
--grant select, insert, update, delete on schema::vwWinkelmandperKlant to Admin1;
--grant select, insert, update, delete on schema::vwProductperCategorie to Admin1;
--exec sp_addrolemember 'Admin1', 'r0857568_Admin';

--grant select, insert, update, delete on schema::WINKELMAND to Klant;
--grant select, insert, update, delete on schema::WINKELMANDITEM  to Klant;

--grant select on schema::KLANT to Klant;
--grant select on schema::PRODUCT  to Klant;
--grant select on schema::CATEGORIE to Klant;
--grant select on schema::MEDEWERKER to Klant;
--grant select on schema::OUDEklanten  to Klant;
--grant select on schema::PRODUCThistory to Klant;
--grant select on schema::PRODUCTCATEGORIE to Klant;
--exec sp_addrolemember 'Klant', 'r0857568_Klant';

----------------------------------------------------INSERTS

--------------------------MEDEWERKERS

go

insert into MEDEWERKER (voornaam, achternaam, code_pasje, passwoord)
values 
('Bruce', 'Wayne', '123', '456'),
('Clark', 'Kent', '456', '789')


--------------------------CATEGORIES



insert into CATEGORIE (naam)
values 
('LAPTOPS'),
('DESKTOPS'),
('MONITOREN')


--------------------------PRODUCTEN

insert into PRODUCT (naam, beschrijving, foto, prijs)
values 

-----LAPTOPS-----
('HP Pavilion 15-eh0073nb Azerty',' Apple MacBook Air (2020) MGN63FN/A Space Gray gebruik je dankzij de Apple M1 chip een hele dag door, zonder tussendoor op te laden. De batterij gaat tot wel 18 uur mee op ��n batterijlading. Deze energiezuinige chip is krachtiger dan de Intel processor in oudere modellen. Hierdoor draai je moeiteloos zware programmas. Bewerk videos met Final Cut Pro of multitask met programmas als Apple Pages. Dankzij de Apple M1 chip doe je het soepel en zonder haperingen. Apple MacBook Air neem je zonder problemen overal mee naartoe. Hij weegt namelijk slechts 1,29 kilogram. Het True Tone Retina beeldscherm past de kleurtemperatuur automatisch aan op de hoeveelheid licht in de ruimte. Zo zie jij altijd heldere, natuurgetrouwe beelden.','C:\Users\valen\source\repos\Solution1\prodImg\1518942.jfif','569'), 
('Apple MacBook Air (2020) MGN63FN/A Space Gray AZERTY',' Apple MacBook Air (2020) MGN63FN/A Space Gray gebruik je dankzij de Apple M1 chip een hele dag door, zonder tussendoor op te laden. De batterij gaat tot wel 18 uur mee op ��n batterijlading. Deze energiezuinige chip is krachtiger dan de Intel processor in oudere modellen. Hierdoor draai je moeiteloos zware programmas. Bewerk videos met Final Cut Pro of multitask met programmas als Apple Pages. Dankzij de Apple M1 chip doe je het soepel en zonder haperingen. Apple MacBook Air neem je zonder problemen overal mee naartoe. Hij weegt namelijk slechts 1,29 kilogram. Het True Tone Retina beeldscherm past de kleurtemperatuur automatisch aan op de hoeveelheid licht in de ruimte. Zo zie jij altijd heldere, natuurgetrouwe beelden.','C:\Users\valen\source\repos\Solution1\prodImg\1503992.jfif','999'), 
('HP Pavilion 15-eh0081nb Azerty','Bewerk fotos in Photoshop of analyseer data in Excel met de HP Pavilion 15-eh0081nb. Je werkt in meerdere Office of Photoshop vensters tegelijkertijd dankzij de krachtige AMD Ryzen 5 processor en 16 gigabyte werkgeheugen. Je laptop loopt niet vast en vertraagt niet. Kijk een Netflix serie in een zonnige tuin op het ontspiegelde beeldscherm. Je hebt op dit scherm geen last van lichtreflecties. Door de Bang & Olufsen speakers klinken stemmen van films en series helder en duidelijk. Werk je in de avond of in een slecht verlichte ruimte? Schakel de toetsenbordverlichting in en werk foutloos verder. Bij een technische storing neem je contact op met HP. Zij sturen een monteur op locatie langs om de problemen op te lossen.','C:\Users\valen\source\repos\Solution1\prodImg\1518927.jfif','649'),
('Lenovo IdeaPad 5 15IIL05 81YK00F3MB Azerty',' Met de Lenovo IdeaPad 5 15IIL05 81YK00F3MB bewerk je een foto, multitask je met allerlei applicaties of doe je de boekhouding. Inloggen doe je snel en veilig met de vingerafdrukscanner. Dat is veiliger en sneller dan een wachtwoord typen. Dankzij 16 gigabyte werkgeheugen draai je meerdere programmas op de achtergrond en multitask je effectiever. Luister naar je eigen muziek via Spotify of luister iets op YouTube. De Intel Core i5 processor is krachtig genoeg voor fotobewerking. Op het verlichte toetsenbord werk en je ook in het donker verder. Wanneer je niet aan het videochatten bent, schuif je het fysieke klepje voor de webcam om je privacy te beschermen.','C:\Users\valen\source\repos\Solution1\prodImg\570x450.41005086_08.jpg','699'),
('Apple MacBook Air (2020) 16GB/512GB Apple M1 met 8 core GPU Space Gray AZERTY', 'Bewerk fotos en videos, schrijf verslagen en kijk series met Apple MacBook Air (2020) 16GB/512GB Apple M1 met 8 core GPU Space Gray. De Apple M1 chip is krachtig genoeg voor zware grafische programmas als Final Cut Pro en werkt effici�nt, waardoor de accu tot wel 18 uur meegaat. Je bewerkt grote foto- en videobestanden zonder haperingen of vastlopers dankzij 16 gigabyte werkgeheugen. Apple MacBook Air neem je zonder problemen overal mee naartoe. Hij weegt namelijk slechts 1,29 kilogram. Het True Tone Retina beeldscherm past de kleurtemperatuur automatisch aan op de hoeveelheid licht in de ruimte. Zo zie jij altijd heldere, natuurgetrouwe beelden.','C:\Users\valen\source\repos\Solution1\prodImg\macbook-air-og-202011.jfif','1599'),
('Asus VivoBook 17 X712JA-AU058T-BE Azerty', 'Met de Asus VivoBook 17 X712JA-AU058T-BE bewerk je fotos en multitask je met Microsoft Office programmas. Open tientallen tabbladen in Chrome of werk in verschillende vensters van Microsoft Word tegelijkertijd. De Intel Core i5 processor en 8 gigabyte werkgeheugen zorgen ervoor dat de Asus snel blijft. Op het grote 17 inch beeldscherm open je twee vensters naast elkaar, waardoor je overzichtelijk en effici�nt werkt. Na het werken bekijk je films en series in full hd. Dat doe je op een zonnige dag ook in de achtertuin of op een terras. Dankzij het ontspiegelde scherm heb je geen last van reflecties van zonlicht.','C:\Users\valen\source\repos\Solution1\prodImg\1532861.jfif','749'),
('Lenovo ThinkBook 15 G2 - 20VE0046MB Azerty', 'Schrijf e-mails, houd je aantekeningen bij en bewerk fotos met Adobe Photoshop met de Levnovo ThinkBook 15 G2 - 20VE0046MB. De 15 inch laptop heeft een Intel Core i5 processor en 8 GB werkgeheugen. Deze onderdelen maken de laptop krachtig genoeg om tussen tabbladen te multitasken en fotos professioneel te bewerken. Deze ThinkBook 15 G2 heeft Windows 10 Pro om je bestanden goed te beschermen. Je verkleint de kans dat anderen bij je bestanden komen als je de vingerafdrukscanner gebruikt. Dit werkt nog veiliger dan een zelfbedacht wachtwoord. Met het verlichte toetsenbord typ je in het donker net zo gemakkelijk door. Je start de laptop en de applicaties snel op dankzij de 256 GB SSD schijf.','C:\Users\valen\source\repos\Solution1\prodImg\1512247.jfif','879'),
('Acer Aspire 5 A515-56-70XN Azerty', 'Gebruik de 15 inch Acer Aspire 5 A515-56-70XN voor zwaardere programmas, zoals Photoshop of Premiere Pro. Multitask tijdens het bewerken van jouw fotos en videos. Dit werkt soepel door de krachtige Intel Core i7 processor en de 16 gigabyte aan werkgeheugen. Het opslaan van grote projecten is ook geen probleem met de snelle 512GB SSD schijf. Je start de Aspire 5 binnen enkele seconden op. Zelfs als het donker is, weet jij de juiste toetsen nog te vinden dankzij het lichtgevende toetsenbord.','C:\Users\valen\source\repos\Solution1\prodImg\1490491.jfif','849'),
('Lenovo IdeaPad Duet Chromebook Tablet 128GB Azerty', 'De Lenovo IdeaPad Duet Chromebook Tablet 128GB is een handzame tablet en Chromebook in ��n. Koppel het meegeleverde toetsenbord aan de tablet en gebruik hem om verslagen in Google docs te schrijven. Klaar met typen? Koppel het toetsenbord dan weer los en gebruik de IdeaPad als tablet en swipe met je vingers door webpaginas heen. Je neemt deze Chromebook gemakkelijk met je mee, omdat hij in totaal slechts 920 gram weegt. Als je hem zonder toetsenbord gebruikt, weegt hij zelfs maar 450 gram. De Lenovo draait op Chrome OS. Je gebruikt applicaties vanuit de Chrome browser of de Google Play store.','C:\Users\valen\source\repos\Solution1\prodImg\1419240.jfif','269'),
('Apple MacBook Air (2020) MGN73FN/A Space Gray AZERTY', 'Apple MacBook Air (2020) MGN73FN/A Space Gray gebruik je dankzij de Apple M1 chip een hele dag door, zonder tussendoor op te laden. De batterij gaat tot wel 18 uur mee op ��n batterijlading. Deze energiezuinige chip is krachtiger dan de Intel processor in oudere modellen. Hierdoor draai je moeiteloos zware programmas. Bewerk videos met Final Cut Pro of multitask met programmas als Apple Pages. Dankzij de Apple M1 chip doe je het soepel en zonder haperingen. Apple MacBook Air neem je zonder problemen overal mee naartoe. Hij weegt namelijk slechts 1,29 kilogram. Het True Tone Retina beeldscherm past de kleurtemperatuur automatisch aan op de hoeveelheid licht in de ruimte. Zo zie jij altijd heldere, natuurgetrouwe beelden.','C:\Users\valen\source\repos\Solution1\prodImg\LD0005649096_2_0005712366.jpg','1219'),

-----DESKTOPS-----

('Apple Mac Mini (2020) 16GB/1TB Apple M1 chip', 'Met Apple Mac Mini (2020) 16GB/1TB Apple M1 chip multitask je met zware programmas als Adobe Photoshop. Dankzij Apples eigen M1 chip doe je dat soepel en zonder haperingen. Deze chip is namelijk tot 3 keer sneller dan de Intel processor in eerdere modellen. Hardware en software zijn beter op elkaar afgestemd, waardoor programmas effici�nter werken en je alle rekenkracht optimaal benut. Dit model beschikt over 16 gigabyte werkgeheugen, waardoor je moeiteloos verschillende zware programmas tegelijk gebruikt. Op de 1 terabyte SSD schijf heb je voldoende ruimte voor al jouw fotos, videos en persoonlijke bestanden. Hoe klein je bureau ook is, dankzij het compacte formaat van 19,7 centimeter breed vind je altijd wel een plek voor Apple Mac Mini.','C:\Users\valen\source\repos\Solution1\prodImg\1503982.jfif','1489'),
('Acer Aspire TC-895 I7510', 'De Acer Aspire TC-895 I7510 is een krachtige computer voor het hele gezin. Je gebruikt hem voor het bijwerken van je e-mail, het bewerken van de vakantievideos of het maken van huiswerk. Ook voor zwaardere programmas zoals Adobe Premiere is deze computer geschikt. Door de snelle Intel Core i7 processor en 16 GB werkgeheugen, multitask je zonder haperingen. Deze desktop heeft een 256 GB SSD schijf, waardoor hij binnen 15 seconden opgestart is. De harde schijf van 1 TB biedt daarnaast voldoende opslagcapaciteit voor al je persoonlijke bestanden, fotos en videos. Omdat hij slechts 34 centimeter hoog is, vind je er gemakkelijk een plek voor op je bureau.','C:\Users\valen\source\repos\Solution1\prodImg\1449089.jfif','849'),
('Acer Predator Orion 3000 620 I710-30G', 'Speel de nieuwste games en die van de toekomst op de Acer Predator Orion 3000 620 I710-30G. Ook speel je probleemloos VR games. De NVIDIA GeForce RTX 3070 videokaart is daar krachtig genoeg voor. Dankzij de 2e generatie raytracing van NVIDIA zie je realistische belichting in games die dit ondersteunen. De Acer draait al jouw programmas zonder haperingen en vastlopers dankzij de Intel Core i7 processor. Met 16 gigabyte RAM heb je voldoende werkgeheugen om met zware programmas te multitasken. Op de 1 terabyte ssd bewaar je jouw favoriete games. Zo starten ze binnen enkele seconden. Al je andere bestanden, films en fotos bewaar je op de 1 terabyte harde schijf.','C:\Users\valen\source\repos\Solution1\prodImg\1457157.jfif','1799'),
('Acer Nitro N50-610 I9424', 'Speel de nieuwste games op ultra instellingen met de Acer Nitro N50-610 I9424. Daar is de NVIDIA RTX 2060 videokaart in deze desktop krachtig genoeg voor. Tijdens het gamen chat je met jouw vrienden op Discord, terwijl je strategie�n opzoekt op YouTube. Dankzij het 16 GB werkgeheugen, doe je dat zonder dat je games gaan haperen. Deze desktop heeft daarnaast een Intel Core i7 processor, waardoor je hem ook gebruikt om videos te bewerken met zware programmas als Adobe Premiere. Games die je bewaart op de 512 GB SSD starten binnen enkele seconden op. De harde schijf van 1 TB geeft je daarnaast voldoende ruimte voor al je persoonlijke bestanden. Tijdens het gamen licht de Acer Nitro op, dankzij de ingebouwde verlichting.','C:\Users\valen\source\repos\Solution1\prodImg\1449106.jfif','1399'),
('Lenovo IdeaCentre G5 14IMB05 90N900D0MH', 'Speel games als Assassins Creed Valhalla op hoge instellingen met de Lenovo IdeaCentre G5 14IMB05 90N900D0MH. De NVIDIA GeForce RTX 2060 videokaart is daar krachtig genoeg voor. De videokaart is ook geschikt voor VR, dus sluit een VR bril aan en speel je favoriete game in virtual reality. Game erop los terwijl je met je vrienden chat op Discord dankzij 16 gigabyte werkgeheugen. Hiermee is multitasken een fluitje van een cent. Je favoriete games installeer je op de 512 gigabyte SSD. Zo starten ze snel op en je hebt veel ruimte voor al je bestanden.','C:\Users\valen\source\repos\Solution1\prodImg\1550076.jfif','999'),
('HP Pavilion Gaming TG01-1305nd', 'Op de HP Pavilion Gaming TG01-1305nd speel je competitieve games als Call of Duty en Fortnite op hoge instellingen. Dankzij de NVIDIA GeForce GTX 1660 Super doe je dat met meer dan 60 frames per seconde. De Intel Core i5 processor en 8 GB werkgeheugen zorgen ervoor dat alles soepel blijft draaien. Zelfs wanneer je op de achtergrond chat met je vrienden via Discord. Deze HP Pavilion Gaming desktop heeft 2 schijven. Op de snelle 256 GB SSD bewaar je jouw favoriete spellen. Zo starten ze snel op en zit je in een mum van tijd in het volgende potje. Jouw overige bestanden bewaar je op de 1 TB HDD.','C:\Users\valen\source\repos\Solution1\prodImg\1283920.jfif','899'),
('Acer Aspire XC-895 I5412', 'Met de compacte Acer Aspire XC-895-I5412 heb je een pc in huis voor het hele gezin. Je zet deze pc eenvoudig op of onder je bureau, omdat hij weinig ruimte inneemt. De kinderen maken hier eenvoudig hun schoolwerk op en voor de ouders is internetten, e-mailen en zelfs het bewerken van fotos geen probleem. Dit komt door de tiende generatie Intel Core i5 processor en de 8 gigabyte aan werkgeheugen. Er zit een 256 GB SSD schijf in voor het snel opstarten van applicaties en een 2 TB HDD schijf voor alle bestanden. Voor ieder gezinslid genoeg ruimte om bijvoorbeeld ongeveer 200.000 fotos op te slaan. Er zijn genoeg aansluitingen voor al je randapparatuur..','C:\Users\valen\source\repos\Solution1\prodImg\1449097.jfif','599'),
('Lenovo Legion T5 28IMB05 90NC00LNMH', 'Speel de nieuwste games op hoge instellingen met de Lenovo Legion T5 28IMB05 90NC00LNMH. De NVIDIA GeForce RTX 2060 videokaart is daar krachtig genoeg voor. De videokaart is ook geschikt voor VR, dus sluit een VR-bril aan en speel je favoriete game in virtual reality. Game erop los terwijl je met je vrienden chat op Discord dankzij 16 GB werkgeheugen. Hiermee is multitasken een fluitje van een cent. Je favoriete games installeer je op de 512 GB SSD. Zo starten ze snel op.','C:\Users\valen\source\repos\Solution1\prodImg\1497694.jfif','1099'),
('Lenovo IdeaCentre G5-14AMR 90Q1002YMH', 'Speel de nieuwste games op hoge instellingen met de Lenovo IdeaCentre G5-14AMR 90Q1002YMH. De NVIDIA GeForce RTX 2060 videokaart is daar krachtig genoeg voor. Game erop los terwijl je met je vrienden chat op Discord dankzij 16 GB werkgeheugen. Hiermee is multitasken een fluitje van een cent. Je favoriete games installeer je op de 512 GB SSD. Zo starten ze snel op. Maak je graag compilaties van je gameprestaties? Door de AMD Ryzen 7 processor bewerk je ook videos op de Lenovo desktop. De 1 TB HDD geeft je voldoende ruimte om je beste videos en overige bestanden te bewaren.','C:\Users\valen\source\repos\Solution1\prodImg','1399'),
('Acer Nitro N50-610 I9426-JK', 'Met de Acer Nitro N50-610 I9426-JK speel je games als Red Dead Redemption 2 op de hoogste instellingen. Dankzij de krachtige NVIDIA GeForce RTX 2060 videokaart speel je games met hoge framerates. Ook ga je dankzij deze videokaart aan de slag met virtual reality. Deze Acer Nitro heeft een Intel Core i5 processor en 16 gigabyte werkgeheugen. Hierdoor multitask je er ook tijdens het gamen op los, zonder dat je games haperen. Dankzij de 512 gigabyte SSD starten jouw games binnen enkele seconden op. Zo zit je in een mum van tijd in de lobby voor je volgende potje.','C:\Users\valen\source\repos\Solution1\prodImg\1457232.jfif','1049'),

-----MONITOREN-----

('Samsung LC34H890WGRXEN', 'Werk in meerdere vensters tegelijk of game in Ultrawide met de Samsung LC34H890WGRXEN. Met dit brede 34 inch scherm zie je veel meer van je games, films en Office programmas. Door de WQHD resolutie is dit scherm ook nog eens zeer scherp, maar liefst 2 keer scherper dan een Ultrawide full hd scherm. De LC34H890WGU ververst 100 keer per seconde, waardoor beelden vloeiend in elkaar overlopen. Het brede scherm is ook zeer geschikt voor (school)werk. Open meerdere tekstdocumenten en spreadsheets naast elkaar, met Spotify ernaast. Even geen zin om te werken? Bekijk dan films zonder zwarte balken aan de boven- en onderkant. Heb je een AMD videokaart? Dan zorgt FreeSync dat deze verversingssnelheid naadloos aansluit op de fps van je videokaart. Daarnaast zorgt de usb C connectiviteit ervoor dat je gemakkelijk een laptop of andere randapparatuur aansluit op de monitor en deze tegelijkertijd oplaadt. Samsung geeft 3 jaar garantie op deze monitor.','C:\Users\valen\source\repos\Solution1\prodImg\LD0005772693_1.jpg','549'),
('LG 27UN83A', 'De LG 27UN83A is een 27 inch monitor voor het bewerken van documenten, fotos en videos. De 4K resolutie is 4 keer scherper dan full hd. Hierdoor zie je elk detail haarscherp, zelfs op dit grote scherm met een doorsnede van 69 centimeter. Dankzij HDR heeft de 27UN83A een hoge helderheid en een breed contrast. Daarnaast heeft deze monitor een IPS paneel dat 99% van het sRGB kleurprofiel dekt. Dit zorgt voor een brede en realistische kleurweergave vanuit elke kijkhoek. Sluit je Windows laptop of MacBook direct aan via de usb C aansluiting, dan laadt hij je apparaat ook gelijk op. En hoewel deze monitor vooral geschikt is voor zakelijke toepassingen, vermindert FreeSync haperingen wanneer je een game speelt.','C:\Users\valen\source\repos\Solution1\prodImg\1445289.jfif','369'),
('Samsung LS27R650', 'De Samsung LS27R650FDUXEN is een 27 inch monitor voor zakelijk gebruik. Deze monitor heeft een strak en vrijwel randloos design, waardoor hij niet misstaat op een kantoor of thuiskantoor. Ook heb je geen last van een hinderlijke brede rand als je de monitor in een twee schermen setup gebruikt. Met de monitor cre�er je een ideale en ergonomische werkhouding voor tijdens het thuiswerken. Draai, roteer en verstel de hoogte van de monitor om zo de juiste zithouding aan te nemen voor je werkdag. Doordat deze monitor een IPS scherm heeft, ervaar je vanuit elke hoek ware kleuren. Werk je lang door? Geen probleem. Het blauw licht filter en de trillingsvrije technologie verminderen vermoeide en ge�rriteerde ogen.','C:\Users\valen\source\repos\Solution1\prodImg\1505284.jfif','198'),
('AOC U2790PQU', 'Kijk films, bewerk fotos en maak digitale ontwerpen voor je werk met de AOC U2790PQU. Deze 27 inch monitor heeft een 4K resolutie, waardoor content tot in de kleinste details in beeld komt. Dankzij de 100% ondersteuning van het sRGB kleurprofiel en 10 bit kleuroutput geeft het scherm kleuren natuurgetrouw weer. Het IPS paneel zorgt ervoor dat de kleuren niet vervagen als je vanuit een scherpe hoek naar het scherm kijkt. Pas de U2790PQU aan jouw ideale werkhouding aan door hem in hoogte te verstellen of het scherm te kantelen. De rand om het scherm is vrijwel niet zichtbaar, waardoor je prettig met meerdere monitoren naast elkaar werkt. Via de ingebouwde usb hub sluit je randapparatuur, zoals een muis of usb stick, aan. Let op: Door 4K worden tekst en icoontjes kleiner, dit kan je niet altijd vergroten. Voor een 4k output heb je een moderne laptop of pc nodig met een redelijk krachtige videokaart. Zorg ook dat deze minimaal een DisplayPort 1.2, HDMI 2.0 of Thunderbolt 3 aansluiting heeft.','C:\Users\valen\source\repos\Solution1\prodImg\1339219.jfif','359'),
('Samsung LS24R650', 'De Samsung LS24R650 is een 24 inch monitor voor zakelijk gebruik. Deze monitor heeft een strak en vrijwel randloos design, waardoor hij niet misstaat op een kantoor of thuiskantoor. Met de monitor cre�er je een ideale en ergonomische werkhouding voor tijdens het thuiswerken. Draai, roteer en verstel de hoogte van de monitor om zo de juiste zithouding aan te nemen voor je werkdag. Gebruik hem daarom ook voor alledaagse dingen, zoals het kijken van videos op YouTube. Doordat deze monitor een IPS scherm heeft, ervaar je vanuit elke hoek ware kleuren. Werk je lang door? Geen probleem. Het blauw licht filter en de trillingsvrije technologie verminderen vermoeide en ge�rriteerde ogen. Je hangt deze monitor aan de muur met een een VESA muurbeugel.','C:\Users\valen\source\repos\Solution1\prodImg\1087418-samsung-ls34j550wqu.jpg','168')


--------------------------KLANTEN



insert into KLANT (voornaam, achternaam, geboortedatum, straat, nummer, postcode, gemeente, gsm)
values 
('Bathsheba', 'Largan', '1997-01-18', 'Elka', '56', '456', 'Hetou','+46-318-364-3507'),

('Anselm', 'Vest', '2000/05/25', 'Sloan', '1', '8465', 'Villa Yapacan�','+86-120-395-6533')
,

('Booth', 'De Biasio', '1999-2-25', 'Birchwood', '1548', '6851', 'Klenovyy','+27-966-533-8006')
,

('Hewett', 'Fotherby', '1997-2-25', 'Bunting', '555', '9500', 'Moerbeke','+255-709-394-7405'),

('Eilis', 'Oherlihy', '1999-7-28', 'Waxwing', '86740', '9500', 'Moerbeke','+351-661-180-8291'),

('Clarence', 'Wildt', '1998-6-16', 'Shopko', '43', '9500', 'Tokyo','+55-475-128-4589'),

('Virge', 'Martello', '2002-12-29', 'Warrior', '8', '9500', 'London','+254-529-845-9939'),

('Maribeth', 'Scandrick', '1998-4-2', 'Pleasure', '974', '3265', 'Huazangsi','+20-465-705-7776'),

('Anne-marie', 'Wildor', '2003-2-28', 'Oxford', '2', '2332', 'London','+86-243-854-9729'),

('Winnie', 'Chavey', '1999-6-27', 'Londonderry', '9180', '22501', 'Paris','+62-602-749-3302')



--------------------------PRODUCTCATEGORIE

insert into PRODUCTCATEGORIE(product_id,categorie_naam)
values 
(1, 'LAPTOPS'),
(2, 'LAPTOPS'),
(3, 'LAPTOPS'),
(4, 'LAPTOPS'),
(5, 'LAPTOPS'),
(6, 'LAPTOPS'),
(7, 'LAPTOPS'),
(8, 'LAPTOPS'),
(9, 'LAPTOPS'),
(10, 'LAPTOPS'),

(11, 'DESKTOPS'),
(12, 'DESKTOPS'),
(13, 'DESKTOPS'),
(14, 'DESKTOPS'),
(15, 'DESKTOPS'),
(16, 'DESKTOPS'),
(17, 'DESKTOPS'),
(18, 'DESKTOPS'),
(19, 'DESKTOPS'),
(20, 'DESKTOPS'),

(21, 'MONITOREN'),
(22, 'MONITOREN'),
(23, 'MONITOREN'),
(24, 'MONITOREN'),
(25, 'MONITOREN')
--------------------------WINKELMANDEN

insert into WINKELMAND (klant_id, _status)
values
(7, 'betaald'), 
(5,'niet betaald'),
(3,'niet betaald'),
(9, 'betaald'),
(1,'betaald')


--------------------------WINKELMANDITEMS

insert into WINKELMANDITEM(winkelmand_id,product_id,  aantal)
values 
(1, 5, 1),
(2,3,1),
(2,24,1),
(3, 12, 1),
(3, 22, 1),
(4, 13, 1),
(4,22,1),
(5, 10, 1),
(5,5,1);

----------------------------------------------------EXTRA VIEW

go
create view vwDeluxeProducten
as select * 
from dbo.fnProductOpzoekenperPrijs(1000);
go
select * from  vwDeluxeProducten