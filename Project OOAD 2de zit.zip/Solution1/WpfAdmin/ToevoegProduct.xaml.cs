﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for ToevoegProduct.xaml
    /// </summary>
    public partial class ToevoegProduct : Window
    {
        PRODUCTwindow prodW;
        public ToevoegProduct(PRODUCTwindow prodW)
        {
            InitializeComponent();
            this.prodW = prodW;
        }

        private void btnAnnuleren_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnToevoegen_Click(object sender, RoutedEventArgs e)
        {
            string naam = txtBnaam.Text;
            int prijs = (int)Convert.ToInt64(txtBpx.Text);
            string beschrijving = txtBpx.Text;
            string foto = "";



            PRODUCTEN prod = new PRODUCTEN(0, naam, beschrijving,foto ,prijs);
            int newId = prod.InsertToDb();
            prodW.ReloadProducten(newId);
        }
    }
}
