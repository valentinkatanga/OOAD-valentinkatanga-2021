﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for KLANTwindow.xaml
    /// </summary>
    public partial class KLANTwindow : Window
    {
        string connString = ConfigurationManager.AppSettings["connString"];
        public KLANTwindow(MainWindow mainWin)
        {
            InitializeComponent();
            ReloadKlanten(null);
        }
        
        public void ReloadKlanten(int? selectedId)
        {
            lstBxitem.Items.Clear();
            lblvn.Content = "";
            lblan.Content = "";
            lblgbd.Content = "";
            lblgmt.Content = "";
            lblnr.Content = "";
            lblpc.Content = "";
            lblstr.Content = "";
            lblGsm.Content = "";

            List<Klanten> alleklanten = Klanten.GetAll();
            foreach (Klanten klant in alleklanten)
            {
                ListBoxItem item = new ListBoxItem();
                item.Content = klant.ToString();
                item.Tag = klant.Id;
                item.IsSelected = selectedId == klant.Id;
                lstBxitem.Items.Add(item);
            }
        }
        /// <summary>
        /// Geselecteerd item in de lijst is veranderd
        /// </summary>
        private void lstBxitem_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)lstBxitem.SelectedItem;
            btnWijzigenK.IsEnabled = item != null;
            btnVerwijderen.IsEnabled = item != null;
            if (item == null) return;

            int klantId = Convert.ToInt32(item.Tag);
            Klanten klant = Klanten.FindById(klantId);
            lblvn.Content = klant.voornaam;
            lblan.Content = klant.achternaam;
            lblgbd.Content = Convert.ToString( klant.geboortedatum);
            lblstr.Content = klant.straat;
            lblpc.Content = klant.postcode;
            lblgmt.Content = klant.gemeente;
            lblnr.Content = klant.nummer;
            lblGsm.Content = klant.gsm;

            
        }




        private void btnWijzigenK_Click(object sender, RoutedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)lstBxitem.SelectedItem;
            int klantId = Convert.ToInt32(item.Tag);

            WijzigKlantW wijzigklant = new WijzigKlantW(this, klantId);
            wijzigklant.Show();
        }

        private void btnToevoegen_Click(object sender, RoutedEventArgs e)
        {
            ToevoegKlant toevoegklant = new ToevoegKlant(this);
            toevoegklant.Show();
        }

        private void btnVerwijderen_Click(object sender, RoutedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)lstBxitem.SelectedItem;
            int KlantenId = Convert.ToInt32(item.Tag);
            Klanten klant = Klanten.FindById(KlantenId);

            // vraag bevestiging
            MessageBoxResult result = MessageBox.Show($"Ben je zeker dat je klant #{KlantenId} wil verwijderen?", "Klant verwijderen", MessageBoxButton.YesNo);
            if (result != MessageBoxResult.Yes) return;

            // verwijder werknemer
            klant.DeleteFromDb();
            ReloadKlanten(null);
        }
    }
}
