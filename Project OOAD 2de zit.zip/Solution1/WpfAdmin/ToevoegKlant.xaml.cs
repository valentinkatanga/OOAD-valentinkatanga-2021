﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary;

namespace WpfAdmin
{

    /// <summary>
    /// Interaction logic for ToevoegKlant.xaml
    /// </summary>
    public partial class ToevoegKlant : Window
    {
        KLANTwindow klantww;
        public ToevoegKlant(KLANTwindow klantww)
        {
            InitializeComponent();
            this.klantww = klantww;
           
        }

        private void btnAnnuleren_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnToevoegen_Click(object sender, RoutedEventArgs e)
        {
            string voornaam = txtBvn.Text;
            string achternaam = txtBan.Text;
            DateTime? geboortedatum = dtPckr.SelectedDate;
            string straat = txtBstr.Text;
            string nummer = txtBnr.Text;
            string postcode = txtBpc.Text;
            string gemeente = txtBgmt.Text;
            string gsm = txtB_gsm.Text;



            Klanten klant = new Klanten(0, voornaam, achternaam, geboortedatum, straat, nummer, postcode, gemeente, gsm);
            int newId = klant.InsertToDb();
            klantww.ReloadKlanten(newId);


        }
    }
}
