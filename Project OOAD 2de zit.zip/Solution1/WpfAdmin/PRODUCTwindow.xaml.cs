﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for PRODUCTwindow.xaml
    /// </summary>
    public partial class PRODUCTwindow : Window
    {
        string connString = ConfigurationManager.AppSettings["connString"];
        public PRODUCTwindow()
        {
            InitializeComponent();
            ReloadProducten(null);
        }
        public void ReloadProducten(int? selectedId)
        {
            lsBox.Items.Clear();
            lblnaam.Content = "";
            lblprijs.Content = "";
            txtBlckbes.Text = "";

            List<PRODUCTEN> alleproducten = PRODUCTEN.GetAll();
            foreach (PRODUCTEN product in alleproducten)
            {
                ListBoxItem item = new ListBoxItem();
                item.Content = product.ToString();
                item.Tag = product.Id;
                item.IsSelected = selectedId == product.Id;
                lsBox.Items.Add(item);

            }
        }
        private void LsBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)lsBox.SelectedItem;
            btnWijzigenK.IsEnabled = item != null;
            btnVerwijderen.IsEnabled = item != null;
            if (item == null) return;

            int prodId = Convert.ToInt32(item.Tag);
            PRODUCTEN prod = PRODUCTEN.FindById(prodId);
            lblnaam.Content = prod.naam;
            lblprijs.Content = "€" + prod.prijs + ",00";
            txtBlckbes.Text = prod.beschrijving;
            


        }

        private void btnToevoegen_Click(object sender, RoutedEventArgs e)
        {
            ToevoegProduct toevoegprod = new ToevoegProduct(this);
            toevoegprod.Show();

        }

        private void btnWijzigenK_Click(object sender, RoutedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)lsBox.SelectedItem;
            int prodId = Convert.ToInt32(item.Tag);
            WijzigProduct wijzigproduct = new WijzigProduct(this, prodId);
            wijzigproduct.Show();
        }

        private void btnVerwijderen_Click(object sender, RoutedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)lsBox.SelectedItem;
            int ProduId = Convert.ToInt32(item.Tag);
            PRODUCTEN product = PRODUCTEN.FindById(ProduId);

            // vraag bevestiging
            MessageBoxResult result = MessageBox.Show($"Ben je zeker dat je klant #{ProduId} wil verwijderen?", "Klant verwijderen", MessageBoxButton.YesNo);
            if (result != MessageBoxResult.Yes) return;

            // verwijder werknemer
            product.DeleteFromDb();
            ReloadProducten(null);
        }
    }
}
