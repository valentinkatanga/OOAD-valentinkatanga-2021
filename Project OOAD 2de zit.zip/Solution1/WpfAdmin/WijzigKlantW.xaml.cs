﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for WijzigKlantW.xaml
    /// </summary>
    public partial class WijzigKlantW : Window
    {
        KLANTwindow klantwindow;
        Klanten klant;
        string connString = ConfigurationManager.AppSettings["connString"];

        public WijzigKlantW(KLANTwindow klantwindow, int id)
        {
            InitializeComponent();
            this.klantwindow = klantwindow;
            klant = Klanten.FindById(id);
            txtBvn.Text = klant.voornaam;
            txtBan.Text = klant.achternaam;
            dtPckr.SelectedDate = klant.geboortedatum;
            txtBstr.Text = klant.straat;
            txtBnr.Text = klant.nummer;
            txtBgmt.Text = klant.gemeente;
            txtBpc.Text = klant.postcode;
            txtB_gsm.Text = klant.gsm;

        }

        private void btnAnnuleren_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnWijzigen_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                klant.voornaam = txtBvn.Text;
                klant.achternaam = txtBan.Text;
                klant.geboortedatum = dtPckr.SelectedDate;
                klant.straat = txtBstr.Text;
                klant.nummer = txtBnr.Text;
                klant.gemeente = txtBgmt.Text;
                klant.postcode = txtBpc.Text;
                klant.gsm = txtB_gsm.Text;
                klant.UpdateInDb();
            }
            klantwindow.ReloadKlanten(klant.Id);
            this.Close();
        }
    }
}
