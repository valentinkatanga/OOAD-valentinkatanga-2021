﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ClassLibrary;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for WijzigProduct.xaml
    /// </summary>
    public partial class WijzigProduct : Window
    {
        PRODUCTwindow prodwindow;
        PRODUCTEN prod;
        string connString = ConfigurationManager.AppSettings["connString"];
        public WijzigProduct(PRODUCTwindow prodwindow, int id)
        {
            InitializeComponent();
            this.prodwindow = prodwindow;
            prod = PRODUCTEN.FindById(id);
            txtBnaam.Text = prod.naam;
            txtBbes.Text = prod.beschrijving;
            txtBprijs.Text = Convert.ToString (prod.prijs);
            
        }

        private void btnAnnuleren_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnWijzigen_Click(object sender, RoutedEventArgs e)
        {
            
                using (SqlConnection conn = new SqlConnection(connString))
                { 
                    prod.naam = txtBnaam.Text;
                    prod.prijs = Convert.ToInt32(txtBprijs.Text);
                    prod.beschrijving = txtBbes.Text;
                    prod.UpdateInDb();
                }
                prodwindow.ReloadProducten(prod.Id);
                this.Close();
            
        }
    }
}
