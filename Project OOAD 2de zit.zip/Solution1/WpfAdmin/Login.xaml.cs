﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using ClassLibrary;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        string connString = ConfigurationManager.AppSettings["connString"];


        public Login()
        {
            InitializeComponent();

        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            
            string codepas = "123";
            string passwoord = "456";
            
                    if (txtBUser.Text == codepas &&
                        PasswordBoxPaswoord.Password == passwoord)
                    {
                        MainWindow _window = new MainWindow();
                        _window.Show();
                        this.Close();
                    }
                    else
                    {
                        lblMsg.Content = "Gebruiker of wachtwoord onjuist";
                
                        txtBUser.Text = "";
                        PasswordBoxPaswoord.Password = "";
                    }

                
            
        }
    }
}